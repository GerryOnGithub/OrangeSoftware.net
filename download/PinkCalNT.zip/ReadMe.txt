
Pink Calendar is an easy to use Calendar and Day Planner program. 

Author
======
gerry@orangesoftware.net

Shareware
==============
This program is shareware. Try it, and if you like it buy it for only $10!

Ordering
========
The included Help file has, not only help, but also ordering instructions.
Or visit http://www.orangesoftware.net

Distrubution
============
You may freely distribute the shareware version, provided that anyone receiving
the program is made aware that the program is shareware.